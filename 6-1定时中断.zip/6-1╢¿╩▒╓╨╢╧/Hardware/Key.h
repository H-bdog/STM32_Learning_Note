#ifndef __KEY_H
#define __KEY_H

char Key_GetNum(void);
void Key_Init(void);
void LED1_Turn(void);
void LED2_Turn(void);


#endif
