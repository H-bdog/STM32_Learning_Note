#include "stm32f10x.h"   
#include "Delay.h"
#include "OLED.h"
#include "Timer.h"
// Device header

uint16_t Hour=17;
uint16_t Min=58;
uint16_t Sec=30;
//uint16_t Num;

int main(void)
{
OLED_Init();
Timer_Init();
	OLED_ShowString(1,1,"Time:");
	OLED_ShowString(2,3,":");
	OLED_ShowString(2,6,":");
	while(1)
	{
		OLED_ShowNum(2,1,Hour,2);
		OLED_ShowNum(2,4,Min,2);
		OLED_ShowNum(2,7,Sec,2);
		//OLED_ShowNum(4,9,Num,2);
		
	}
	
}	
void TIM2_IRQHandler(void)//配置TIM的中断函数
{	
	if(TIM_GetITStatus(TIM2,TIM_IT_Update)==SET)	//通过判断标志位来判断是否应该调用中断函数，此处通过判断更新中断的标志位来判断（我也不懂为什么）
	{	//Num++;
		Sec++;
		if(Sec==60)
		{
		
			Sec=0;
			Min++;
		}
		if(Min==60)
		{
		
			Min=0;
			Hour++;
		}
		if(Hour==24)
		{
		
			Hour=0;
		}
		TIM_ClearITPendingBit(TIM2,TIM_IT_Update);//清除标志位
	}

}



