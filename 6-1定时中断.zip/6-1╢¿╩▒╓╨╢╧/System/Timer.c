#include "stm32f10x.h"                  // Device header

//extern uint16_t Num

void Timer_Init(void){
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2,ENABLE);
	
	TIM_InternalClockConfig(TIM2);//TIM2 use Internal timer
	
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructue;
	TIM_TimeBaseInitStructue.TIM_ClockDivision=TIM_CKD_DIV1;
	TIM_TimeBaseInitStructue.TIM_CounterMode=TIM_CounterMode_Up;;
	TIM_TimeBaseInitStructue.TIM_Period=10000 -1;
	TIM_TimeBaseInitStructue.TIM_Prescaler=7200 -1;// these 2 value is for setting time rate, there is a function to calcuate.
	TIM_TimeBaseInitStructue.TIM_RepetitionCounter=0;
	TIM_TimeBaseInit(TIM2,&TIM_TimeBaseInitStructue);
	
	TIM_ITConfig(TIM2,TIM_IT_Update,ENABLE);//TIM中断配置
	/*开始配置计时器的中断函数*/
	NVIC_InitTypeDef NVIC_InitSructure;
	NVIC_InitSructure.NVIC_IRQChannel= TIM2_IRQn;//找到TIM2专用的中断通道，并填进去
	NVIC_InitSructure.NVIC_IRQChannelCmd=ENABLE;
	NVIC_InitSructure.NVIC_IRQChannelPreemptionPriority=2;
	NVIC_InitSructure.NVIC_IRQChannelSubPriority=1;
	NVIC_Init(&NVIC_InitSructure);
	TIM_Cmd(TIM2,ENABLE);
}

//void TIM2_IRQHandler(void)//配置TIM的中断函数
//{
//	if(TIM_GetITStatus(TIM2,TIM_IT_Update)==SET)	//通过判断标志位来判断是否应该调用中断函数，此处通过判断更新中断的标志位来判断（我也不懂为什么）
//	{
//		
//		TIM_ClearITPendingBit(TIM2,TIM_IT_Update);//清除标志位
//	}
//}



